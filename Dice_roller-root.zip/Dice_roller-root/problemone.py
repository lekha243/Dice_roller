def Total_Outcomes():
    Number_of_faces=6
    Number_of_dice=2
    s=pow(Number_of_faces,Number_of_dice)
    a=str(s)
    return a